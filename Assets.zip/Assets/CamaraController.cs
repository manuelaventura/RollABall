using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CamaraController : MonoBehaviour
{
    // Referencia a nuestro jugador
    public GameObject jugador;

    // Para registrar la diferencia entre la posici�n de la c�mara y la del jugador
    private Vector3 offset;

    // Se ejecuta al iniciar el juego
    void Start()
    {
        // Calcula la diferencia inicial entre c�mara y jugador
        offset = transform.position - jugador.transform.position;
    }

    // Se ejecuta cada frame, despu�s de que todo se ha procesado
    void LateUpdate()
    {
        // Mantiene la c�mara en la misma posici�n relativa al jugador
        transform.position = jugador.transform.position + offset;
    }
}
