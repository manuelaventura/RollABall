﻿using UnityEngine;
using UnityEngine.UI;

public class JugadorController : MonoBehaviour
{
    private Rigidbody rb;
    public float velocidad = 10f;

    private int contador;
    public UnityEngine.UI.Text textoContador;
    public UnityEngine.UI.Text textoGanar;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        contador = 0;

        ActualizarTexto();

        if (textoGanar != null)
            textoGanar.text = "";
    }

    void FixedUpdate()
    {
        float movimientoH = Input.GetAxis("Horizontal");
        float movimientoV = Input.GetAxis("Vertical");

        Vector3 movimiento = new Vector3(movimientoH, 0.0f, movimientoV);
        rb.AddForce(movimiento * velocidad);
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Coleccionable"))
        {
            other.gameObject.SetActive(false);
            contador++;
            ActualizarTexto();
        }
    }

    void ActualizarTexto()
    {
        if (textoContador != null)
            textoContador.text = "Contador: " + contador;

        if (contador >= 12 && textoGanar != null)
            textoGanar.text = "¡Ganaste!";
    }
}
